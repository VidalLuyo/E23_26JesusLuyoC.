package ADMINISTRATOR;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Registrar {
    public static void main(String[] args) {
        // Datos del administrador a insertar
        int id = 11;
        String nombre = "John";
        String apellido = "Doe";
        String dni = "12345678";
        String email = "johndoe@example.com";
        String password = "secretpassword";

        // Configuración de la conexión a la base de datos
        String url = "jdbc:sqlserver://localhost:1433;databaseName=E23_26JesusLuyo;";
        String username = "sa";
        String passwordDB = "admin";

        try (Connection conn = DriverManager.getConnection(url, username, passwordDB)) {
            // Consulta SQL para insertar un administrador
            String query = "INSERT INTO ADMINISTROR (id, name, last_name, dni, email, password, active) VALUES (?, ?, ?, ?, ?, ?, 'A')";

            // Preparar la sentencia SQL
            PreparedStatement statement = conn.prepareStatement(query);
            statement.setInt(1, id);
            statement.setString(2, nombre);
            statement.setString(3, apellido);
            statement.setString(4, dni);
            statement.setString(5, email);
            statement.setString(6, password);

            // Ejecutar la consulta
            statement.executeUpdate();

            System.out.println("Administrador insertado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al insertar el administrador: " + e.getMessage());
        }
    }
}
