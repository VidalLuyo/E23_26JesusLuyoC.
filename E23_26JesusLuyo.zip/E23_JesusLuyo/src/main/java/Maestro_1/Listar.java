package Maestro_1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Listar {
    public static void main(String[] args) {
        String url = "jdbc:sqlserver://localhost:1433;databaseName=E23_26JesusLuyo;";
        String username = "sa"; 
        String password = "admin"; 

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "SELECT * FROM PRODUCT";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int productId = resultSet.getInt("id");
                String productName = resultSet.getString("name");
                String productDesciption = resultSet.getString("desciption");
                double productPrice = resultSet.getDouble("price");
                int productAmount = resultSet.getInt("amount");

                System.out.println("-----------------------");
                System.out.println("ID: " + productId);
                System.out.println("Nombre: " + productName);
                System.out.println("Descripción: " + productDesciption);
                System.out.println("Precio: " + productPrice);
                System.out.println("Cantidad: " + productAmount);
            }
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }
}
