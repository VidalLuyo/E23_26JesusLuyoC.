package Maestro_1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Actualizar {
    public static void main(String[] args) {
        int id = 11;
        String name = "Queso";
        String desciption = "El mejor queso";
        double price = 7.99;
        int amount = 5;

        String url = "jdbc:sqlserver://localhost:1433;databaseName=E23_26JesusLuyo;";
        String username = "sa"; 
        String password = "admin";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String sql = "UPDATE PRODUCT SET name = ?, desciption = ?, price = ?, amount = ? WHERE id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setString(1, name);
            statement.setString(2, desciption);
            statement.setDouble(3, price);
            statement.setInt(4, amount);
            statement.setInt(5, id);

            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("El registro se ha actualizado correctamente.");
            } else {
                System.out.println("No se ha encontrado el registro a actualizar.");
            }
        } catch (SQLException e) {
            System.out.println("Error al conectar a la base de datos: " + e.getMessage());
        }
    }
}
