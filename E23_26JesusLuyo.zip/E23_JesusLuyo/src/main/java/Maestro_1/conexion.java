package Maestro_1;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class conexion {

    public static void main(String[] args) {
        Connection conn = null;
        try {
            // Establecer la conexión
            String url = "jdbc:sqlserver://localhost:1433;databaseName=E23_26JesusLuyo;";
            String nombreDeUsuario = "sa";
            String contraseña = "admin";
            conn = DriverManager.getConnection(url, nombreDeUsuario, contraseña);

            // Si la conexión se establece correctamente, imprimir un mensaje
            if (conn != null) {
                System.out.println("Conexión exitosa a la base de datos.");
            }
        } catch (SQLException e) {
            // Si hay un error al establecer la conexión, imprimir un mensaje de error
            System.out.println("Error al establecer la conexión: " + e.getMessage());
        } finally {
            // Cerrar la conexión
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}

